import os

import cv2
import pandas as pd


def mkdir_if_not_exist(path):
    if not os.path.exists(path):
        os.mkdir(path)


def open_or_exit(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        print("Error while opening video file! \n")
        exit(-1)
    else:
        return cap


def get_dataset_stats(annotations):
    # Stats applied on droplets
    droplets_stats = pd.DataFrame()
    droplets_stats["Width"] = annotations.loc[annotations["Label"] == "Droplet"].apply(
        lambda row: row["XMax"] - row["XMin"], axis=1)
    droplets_stats["Height"] = annotations.loc[annotations["Label"] == "Droplet"].apply(
        lambda row: row["YMax"] - row["YMin"], axis=1)

    droplets_stats.drop(droplets_stats[droplets_stats["Width"] < 268].index, inplace=True)

    # Stats applied on cells
    cells_stats = pd.DataFrame()
    cells_stats["Width"] = annotations.loc[annotations["Label"] == "Cell"].apply(
        lambda row: row["XMax"] - row["XMin"], axis=1)
    cells_stats["Height"] = annotations.loc[annotations["Label"] == "Cell"].apply(
        lambda row: row["YMax"] - row["YMin"], axis=1)

    print("=== Droplets ===")
    print("- Mean -\n", droplets_stats.mean(axis=0))
    print("\n- Std -\n", droplets_stats.std(axis=0))

    print("\n=== Cells ===")
    print("- Mean -\n", cells_stats.mean(axis=0))
    print("\n- Std -\n", cells_stats.std(axis=0))

import numpy as np
import cv2

def gaussian_filter(kx, ky, img):
    kernel = (ky, kx)
    gauss_image = cv2.GaussianBlur(img, kernel, 0)
    
    return gauss_image


def droplet_bbox(video_path):

	video = cv2.VideoCapture(video_path)

	# Extracting first frame
	ret, img = video.read()
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	background = gray.copy()
	background = gaussian_filter(5,5,background)
	threshold = 25
	alpha = 0.05

	n_frame = 0
	result_array = []
	cropped_img_list = []

	while video.isOpened():

		ret, img = video.read()
	    
		if not ret:
			video.release()
			cv2.destroyAllWindows()
			break
	    
		gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		gray = gaussian_filter(5,5,gray)
		mask = np.abs(gray-background) > threshold

		################################
		### Bounding box of droplets ###
		################################

		bbox_detect_image = mask.astype(np.uint8).copy()
		bbox_detect_image[bbox_detect_image == 1] = 255
		img_height, img_width = bbox_detect_image.shape
		
		canny_threshold = 100
		# detects edges in the image
		canny_output = cv2.Canny(bbox_detect_image, canny_threshold, canny_threshold*2)
		# finds the contours of these edges
		contours, _ = cv2.findContours(canny_output, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

		bbox_detect_image =  cv2.cvtColor(bbox_detect_image,cv2.COLOR_GRAY2RGB)
		# If we have no contours, then no bounding boxes can be drawn
		if len(contours) != 0:
			#perhaps after all this, do an else and return the information that no bbox was found

			contours_poly = [None]*len(contours)
			boundRect = [None]*len(contours)

			for i,c in enumerate(contours):
				contours_poly[i] = cv2.approxPolyDP(c, 3, True)
				boundRect[i] = cv2.boundingRect(contours_poly[i])

			# Handcrafting a bbox using leftmost and rightmost bounding boxes, of bboxes with a given minimal area

			bbox_array = np.array(boundRect)
			areas = bbox_array[:,2] * bbox_array[:,3]

			image_edge_area_threshold = 140
			got_left = False
			got_right = False

			# Checking for bboxes sufficiently large and which's left edge is close to x = 0
			left_bboxes = bbox_array[(bbox_array[:,0] <= 5) & (areas > image_edge_area_threshold)]
			if left_bboxes.size != 0:
				leftmost_x = 0
				got_left = True

			# Checking for bboxes sufficiently large and which's right edge is close to x = img_width
			right_bboxes = bbox_array[((bbox_array[:,0] + bbox_array[:,2]) >= img_width-5) & (areas > image_edge_area_threshold)]
			if right_bboxes.size != 0:
				rightmost_x = img_width
				got_right = True

			area_threshold = 2000
			if not bbox_array[areas > area_threshold].size == 0:
				bbox_array = bbox_array[areas > area_threshold]
				
				if not got_left:
					leftmost_x = np.min(bbox_array[:,0])

				if not got_right:
					right_x = bbox_array[:,0] + bbox_array[:,2] # computes the x's of the right side of the rectangles
					rightmost_x = np.max(right_x)
				
				new_x = leftmost_x
				new_w = rightmost_x - leftmost_x

				# # Draws the bounding box around the droplet
				# cv2.rectangle(bbox_detect_image, (new_x, 0), (new_x+new_w, img_height), (0,255,0),4)

				# Crops the image to keep only what's inside the bounding box
				cropped_image = gray[0:img_height, new_x:new_x+new_w]

				if n_frame >= 400:
					ret_array = np.array(["frame_"+str(n_frame), str(new_x), str(0), 
										str(new_x+new_w), str(img_height), "droplet"])
					cropped_img_list.append(cropped_image)
				else:
					ret_array = np.array(["frame_"+str(n_frame), "None", "None", "None", "None", "None"])
					cropped_img_list.append(None)

			else:
				ret_array = np.array(["frame_"+str(n_frame), "None", "None", "None", "None", "None"])
				cropped_img_list.append(None)

		else:
			ret_array = np.array(["frame_"+str(n_frame), "None", "None", "None", "None", "None"])
			cropped_img_list.append(None)


			# # Draws the bounding boxes that were initially detected, and that were used to create the final bbox
			# for i in range(len(contours)):
			# 	color = (0, 0, 255)
			# 	cv2.rectangle(bbox_detect_image, (int(boundRect[i][0]), int(boundRect[i][1])), \
			# 		(int(boundRect[i][0]+boundRect[i][2]), int(boundRect[i][1]+boundRect[i][3])), color, 2)


		background = alpha * gray + (1-alpha) * background
		n_frame += 1
		result_array.append(ret_array)


		# # Displaying
		# cv2.imshow('BBOX', bbox_detect_image)
		# cv2.imshow('Sequence', gray)
		# cv2.imshow('Mask', mask.astype(float))
		# cv2.imshow('Masked sequence', masked_gray)
		# print(f'frame {n_frame}')

		# k = cv2.waitKey(0) & 0xff
		# if k == ord('q'): # Allows to close window when pressing the 'q' key
		# 	video.release()
		# 	cv2.destroyAllWindows()
		# 	break

	video.release()
	cv2.destroyAllWindows()
	result_array = np.array(result_array)

	return result_array, cropped_img_list



if __name__ == "__main__":

	path = '../Images/Our_images/9874553/group5.mp4'

	ret_arr, ret_list = droplet_bbox(path)
	print(ret_arr.shape)
	print(len(ret_list))
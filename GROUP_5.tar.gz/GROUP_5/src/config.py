import os

PROJECT_ROOT = "/home/fares/PycharmProjects/Computer_Vision"
DATASET_ROOT = os.path.join(PROJECT_ROOT, "dataset")
FRAME_RATE = 30
WANDB_KEY = "/home/fares/.wandb_api_key"

# These were learned through stats on the test dataset
BACKGROUND_FREQ = 0.9997
CELL_FREQ = 0.0003


def unet_hyperparameters():
    return {
        "dataset_path": os.path.join(DATASET_ROOT, "clean"),
        "seed": 15,
        "test_split": 0.33,
        "input_size": (64, 64),
        "model_features": [64, 128, 256],
        "batch_size": 128,
        "num_worker": 5,
        "learning_rate": 0.005,
        "pin_memory": True
    }

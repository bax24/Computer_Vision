import os

import wandb
from pytorch_lightning import Trainer, seed_everything
from pytorch_lightning.callbacks import ModelCheckpoint
from pytorch_lightning.loggers import WandbLogger

from src.config import PROJECT_ROOT, WANDB_KEY, unet_hyperparameters
from src.models.UNet import UNet


def get_checkpoint_callback():
    return ModelCheckpoint(
        monitor="val_loss",
        dirpath=os.path.join(PROJECT_ROOT, "models/"),
        filename="features-64-128-256-{epoch:02d}-{val_loss:.5f}",
        save_top_k=1,
        mode="min"
    )


def init_training():
    seed_everything(hparams["seed"], workers=True)
    with open(WANDB_KEY, "r") as wandb_key:
        wandb.login(key=wandb_key.read()[:-1])


if __name__ == "__main__":
    hparams = unet_hyperparameters()
    init_training()

    model = UNet(1, 2, args=hparams)
    wandb_logger = WandbLogger(project="Computer vision", log_model="all")
    wandb_logger.watch(model)

    callback = get_checkpoint_callback()
    trainer = Trainer(
        gpus=1,
        precision=16,
        check_val_every_n_epoch=1,
        auto_lr_find=False,
        max_epochs=5,
        logger=wandb_logger,
        callbacks=[callback]
    )

    trainer.tune(model)
    trainer.fit(model)

    UNet(1, 2, args=hparams).load_from_checkpoint(callback.best_model_path)
    trainer.validate(model)

import cv2
import numpy as np
import torch.cuda

from src.config import unet_hyperparameters
from src.models.UNet import UNet

if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    hparams = unet_hyperparameters()
    model = UNet(1, 2, args=hparams).load_from_checkpoint(
        "/home/fares/PycharmProjects/Computer_Vision/models/features-64-128-256-512-epoch=14-val_loss=0.00244.ckpt")
    model.to(device)
    model.eval()

    val_dataloader = model.val_dataloader()

    for x, y in val_dataloader:
        x = x.to(device)
        with torch.no_grad():
            logits = model(x)
            preds = torch.sigmoid(logits.to("cpu"))
        y_hat = torch.tensor((preds >= 0.5).clone().detach(), dtype=torch.uint8, device="cpu")

        cv2.imshow("Frame", np.array(preds[0, 0, :, :], dtype=np.uint8))
        cv2.imshow("Ground truth", np.array(y[0, 0, :, :], dtype=np.uint8) * 255)
        cv2.imshow("Prediction", np.array(y_hat[0, 0, :, :], dtype=np.uint8) * 255)
        cv2.waitKey(-1)

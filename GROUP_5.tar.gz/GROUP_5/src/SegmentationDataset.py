import os

import numpy as np
import pandas as pd
import torch.utils.data
from PIL import Image
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.config import DATASET_ROOT

# Parameters computed through statistical analysis of the dataset
CELL_RADIUS = 20 / 2
DROPLET_RADIUS = 312 / 2
DROPLET_THICKNESS = 5

# Weights used during the computation of the loss
class_weights = [26661424, 26661424 / 7633]


class SegmentationDataset(torch.utils.data.Dataset):
    def __init__(self, dataset_dir, train=True, test_size=0.2, image_dim=(64, 64), seed=None, normalize_dataset=True):
        super(SegmentationDataset, self).__init__()
        self.image_dim = image_dim
        self.normalize_dataset = normalize_dataset
        self.dataset_dir = dataset_dir

        # Load all annotations
        self.annotations = None
        self.load_annotations()

        # Keep only the annotations of droplets
        droplet_annotations = self.filter_annotations()

        # Spit into a trainset and testset
        train_ds, test_ds = train_test_split(droplet_annotations, test_size=test_size, random_state=seed)
        if train:
            self.droplet_annotations = train_ds
        else:
            self.droplet_annotations = test_ds

        self.mean, self.std = 0, 1
        if self.normalize_dataset:
            self.mean, self.std = self.compute_mean_std(256)

    def load_annotations(self):
        annotations_path = os.path.join(self.dataset_dir, "annotations")
        images_path = os.path.join(self.dataset_dir, "images")
        listed_groups = os.listdir(images_path)

        for g in listed_groups:
            csv_path = f"{annotations_path}/{g}.csv"
            annotations = pd.read_csv(csv_path, header=[0], sep=";")
            annotations["Filename"] = annotations["Slice"].apply(lambda x: f"{images_path}/{g}/frame_{x}.jpg")

            # Append annotations
            if self.annotations is None:
                self.annotations = annotations
            else:
                self.annotations = self.annotations.append(annotations, ignore_index=True)

    def filter_annotations(self):
        droplet_annotations = self.annotations.loc[lambda df: df["Label"] == "Droplet"]
        droplet_annotations["Width"] = droplet_annotations.apply(lambda df: df["XMax"] - df["XMin"], axis=1)
        droplet_annotations.drop(droplet_annotations[droplet_annotations["Width"] < 268].index,
                                 inplace=True)
        droplet_annotations.drop(droplet_annotations[droplet_annotations["Width"] > 400].index,
                                 inplace=True)
        droplet_annotations.drop(droplet_annotations[droplet_annotations["Slice"] < 400].index,
                                 inplace=True)
        return droplet_annotations

    def __getitem__(self, idx):
        img_path = self.droplet_annotations.iloc[idx].Filename
        target = self.annotations.loc[self.annotations.Filename == img_path]
        image = np.array(Image.open(img_path).convert("L"))
        image, mask = extract_cell(image, target)

        image = np.resize(image, self.image_dim)
        image = torch.tensor(np.array([image]), dtype=torch.float32)

        mask = np.resize(mask, self.image_dim)
        return self.normalize(image), mask

    def compute_mean_std(self, batch_size=32):
        print("\nSegmentationDataset: Computing mean and std of the dataset")
        loader = DataLoader(self, batch_size=batch_size, num_workers=2, shuffle=False)
        mean = 0.
        std = 0.
        for images, _ in tqdm(loader):
            images = images.to("cuda" if torch.cuda.is_available() else "cpu")
            batch_samples = images.size(0)  # batch size (the last batch can have smaller size!)
            images = images.view(batch_samples, images.size(1), -1)
            mean += images.mean(2).sum(0).cpu()
            std += images.std(2).sum(0).cpu()

        mean /= len(loader.dataset)
        std /= len(loader.dataset)
        return mean, std

    def __len__(self):
        return len(self.droplet_annotations)

    def normalize(self, array):
        return (array - self.mean) / self.std

    def get_classes_count(self, batch_size=32):
        print("\nSegmentationDataset: Computing the weights of the classes")
        loader = DataLoader(self, batch_size=batch_size, num_workers=2, shuffle=False)

        positive_pixels = 0.
        total_pixels = 0.
        for _, mask in tqdm(loader):
            positive_pixels += mask.ravel().sum()
            total_pixels += mask.ravel().size(0)

        cells_count = positive_pixels
        background = total_pixels - positive_pixels
        print("Positive pixels: ", cells_count)
        print("Background pixels: ", background)


def extract_cell(image, target):
    cell_mask = np.zeros(image.shape, dtype=np.int64)
    xmin, ymin = np.inf, np.inf
    xmax, ymax = np.NINF, np.NINF

    droplet_seen = False
    for idx, row in target.iterrows():
        if row["Label"] == "Droplet" and droplet_seen is False:
            droplet_seen = True
            xmin = min(xmin, row["XMin"])
            xmax = max(xmax, row["XMax"])
            ymin = min(ymin, row["YMin"])
            ymax = max(ymax, row["YMax"])

        center_x = (row["XMin"] + row["XMax"]) / 2
        center_y = (row["YMin"] + row["YMax"]) / 2

        if row["Label"] == "Cell":
            mask = draw_mask(image.shape, (center_x, center_y), CELL_RADIUS)
            cell_mask[np.where(mask > 0)] = bool(1)

    image = image[ymin:ymax, xmin:xmax]
    cell_mask = cell_mask[ymin:ymax, xmin:xmax]
    return image, cell_mask


def check_border(x, row, img_shape):
    if x - DROPLET_RADIUS < 0:
        x = row["XMax"] - DROPLET_RADIUS
    elif x + DROPLET_RADIUS > img_shape[1]:
        x = row["XMin"] + DROPLET_RADIUS
    return x


def draw_mask(shape, center, radius):
    y, x = np.ogrid[:shape[0], :shape[1]]
    center_dist = np.sqrt((x - center[0]) ** 2 + (y - center[1]) ** 2)
    return center_dist <= radius


if __name__ == "__main__":
    # generate_dataset()

    d = SegmentationDataset(os.path.join(DATASET_ROOT, "clean"), train=True, test_size=0.33, seed=15,
                            normalize_dataset=False)
    d.get_classes_count()

    # key = ord("a")
    # while key != ord("q"):
    #     img, mask = d[np.random.randint(len(d))]
    #     mask = mask.astype(np.uint8) * 255
    #
    #     cv2.imshow("Image", img)
    #     cv2.imshow('Mask', mask)
    #     cv2.waitKey(-1)
    #     key = cv2.waitKey(10)
